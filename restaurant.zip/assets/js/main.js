function responsive() {
  var menu = document.querySelector(".second-header-bg");
  menu.classList.toggle('d-block');
}